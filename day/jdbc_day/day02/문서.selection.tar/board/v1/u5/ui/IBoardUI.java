package board.v1.u5.ui;

public interface IBoardUI {
	public void execute() throws Exception;
}
