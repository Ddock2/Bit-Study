package board.v1.u4;

import board.v1.u4.ui.BoardUI;

public class BoardMain {
	public static void main(String[] args) {
		BoardUI ui = new BoardUI();
		ui.execute();
	}
}
