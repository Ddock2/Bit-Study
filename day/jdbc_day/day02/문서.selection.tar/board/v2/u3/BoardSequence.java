package board.v2.u3;

public class BoardSequence {
	private static int no = 1;
	
	public static int getNo() {
		return no++;
	}
}
