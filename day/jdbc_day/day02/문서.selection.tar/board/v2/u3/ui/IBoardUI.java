package board.v2.u3.ui;

public interface IBoardUI {
	public void execute() throws Exception;
}
