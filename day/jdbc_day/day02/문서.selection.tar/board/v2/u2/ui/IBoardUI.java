package board.v2.u2.ui;

public interface IBoardUI {
	public void execute() throws Exception;
}
