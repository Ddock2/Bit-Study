package board.v2.u1.ui;

public interface IBoardUI {
	public void execute() throws Exception;
}
