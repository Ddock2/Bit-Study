package board.v2.u4.ui;

public interface IBoardUI {
	public void execute() throws Exception;
}
